console.log("Meu primeiro projeto no console");

            var firstName = "Rebeca";
            var lastName = "Kapoor";

/*
Concatene o primeiro e último nome para imprimir o nome inteiro da pessoa no console. 

Digite a linha: "firstNameconcat(lastName)"
*/
            var fullName =  ;
            console.log(fullName);

            var a = 10;
            var b = 5;
/*
Crie uma variável chamada add e guarda o valor da adição de a e b neste variável.

Digite: var add = a + b

Então, imprima a variável para exibir o valor da adição

Digite: console.log(add)
*/
            var add =   ;
            console.log( );

/*
Crie uma variável chamada sub e guarde o valor da subtração de a e b nesta variável.

Digite: var sub = a - b

Então, imprima a variável para exibir o valor da subtração

Digite: console.log(sub)
*/
            var sub =   ;
            console.log( );

/*
Crie uma variável chamada multiple e guarde o valor da multiplicação de a e b nesta variável.

Digite: var multiple = a * b

Então, imprima a variável para exibir o valor da multiplicação

Digite: console.log(multiple)
*/
            var multiple =   ;
            console.log();

            var divide = a / b ;
            console.log(divide);